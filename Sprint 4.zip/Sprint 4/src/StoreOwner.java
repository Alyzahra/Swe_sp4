
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;
import java.util.Random;

import test.Products;

import java.awt.List;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;



public class StoreOwner  extends User   implements Products{

	private Store Add_store;
	private Admin Approve_products;	
	
	private Products1 StoreOwner_Add;
	private Statistics viewers;
	private Object inputFile;		
      
public void addStore() throws IOException {
	Store Add_store = new Store();
	Add_store.IsOnline();
}
	 
public void addProduct() throws IOException {
	// TODO Auto-generated method stub
   
	File f = new File("StoreProducts.txt");
	FileWriter h = new FileWriter(f, true);
	Products1 StoreOwner_Add = new Products1();
	System.out.println("Enter name");
	Scanner x = new Scanner(System.in);
	StoreOwner_Add.setName(x.next());
	System.out.println("Enter price");
	Scanner y = new Scanner(System.in);
	StoreOwner_Add.setPrice(y.next());
	System.out.println("Enter Brand");
	Scanner u = new Scanner(System.in);
	StoreOwner_Add.setBrand(u.next());
	System.out.println("Enter category");
	Scanner p = new Scanner(System.in);
	StoreOwner_Add.setCategory(p.next());
	Admin Approve_products = new Admin();
	if(Approve_products.approveProduct(StoreOwner_Add.getName())==true) {
	h.write(StoreOwner_Add.getName());
	h.write("\n");
	h.write(StoreOwner_Add.getPrice());
	h.write("\n");
	h.write(StoreOwner_Add.getBrand());
	h.write("\n");
	h.write(StoreOwner_Add.getCategory());
	h.write("\n");
	System.out.println("Product Is Added Successfuly");
	h.close();	
	
	}
	else {
		System.out.println("Product Is Not Approved");
	}
}
public String deleteProduct1() {
	System.out.println("Please enter the product name you want to delete ");
	Scanner x1 = new Scanner(System.in);
	String deleted=x1.next();
	return deleted;
}

public void deleteProduct() throws IOException {
	File inputFile = new File("StoreProducts.txt");
	File tempFile = new File("newFile.txt");

	BufferedReader reader = new BufferedReader(new FileReader(inputFile));
	BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

	String lineToRemove = deleteProduct1();
	String s0;
	String s1;
	String s2;
	String s3;

while((s0 = reader.readLine()) != null&(s1 = reader.readLine()) != null&(s2 = reader.readLine()) != null&(s3 = reader.readLine()) != null) {
	    // trim newline when comparing with lineToRemove
	    String trimmedLine0 = s0.trim();
	    String trimmedLine1 = s1.trim();
	    String trimmedLine2 = s2.trim();
	    String trimmedLine3 = s3.trim();
	    if(trimmedLine0.equals(lineToRemove)) continue;
	    writer.write(s0 + System.getProperty("line.separator"));
	    writer.write(s1 + System.getProperty("line.separator"));
	    writer.write(s2 + System.getProperty("line.separator"));
	    writer.write(s3 + System.getProperty("line.separator"));
	   }
writer.close(); 
reader.close(); 
inputFile.delete();
boolean successful = tempFile.renameTo(inputFile);
System.out.println("Product Is deleted  Successfuly");
	}



/*public void Edit() throws IOException  {
	File f = new File("AdminProducts.txt");
	FileReader r = new FileReader(f);
	Scanner read = new Scanner(f);
	String s,s1 = null ;
	while(read.hasNext()) {
	        s = read.nextLine();
	        s1=read.nextLine();
	         if(s.equalsIgnoreCase(i)){
}



*/
public  void EditProduct1() throws IOException {
	System.out.println("Please enter the product name you want to Edit");
	Scanner x1 = new Scanner(System.in);
	String edited=x1.next();
	System.out.println("Please enter the new product price ");
	Scanner x2 = new Scanner(System.in);
	String edited2=x2.next();
	replaceLines(edited ,edited2);
	
}

//public void replaceLines(String edited,String edited2) throws IOException  {
 /*	 File file=new File("");
      String s1 ;
     
      FileReader fr = new FileReader("");
      BufferedReader br = new BufferedReader(fr);
      //FileWriter fw = new FileWriter(, true);
      
      while ((s1 = br.readLine()) != null) { // read a line
      	if(s1.equals(s)) {
   	    FileWriter fw = new FileWriter("StoresDB.txt", false);
           int x=0;
 
   	    fw.write("\r\n");
           fw.flush();
           fw.close();
   		break;
   	}
     	//Store obj = new Store(list[0],list[1],list[2],list[3]);
      }
      br.close(); */
	
	/*ArrayList<String> fileContent = new ArrayList<>(Files.readAllLines("F:\College\Software Engineering 2 project code\Sprint 4\Sprint 4\StoreProducts",StandardCharsets.UTF_8));

	for (int i = 0; i < fileContent.size(); i++) {
	    if (fileContent.get(i).equals("old line")) {
	        fileContent.set(i, "new line");
	        break;
	    }
	}

	Files.write("StoreProducts", fileContent, StandardCharsets.UTF_8);
}*/
	
	
	/*  static void modifyFile(String filePath, String edited2, String edited2)
	    {
	        File fileToBeModified = new File(filePath);
	         
	        String oldContent = "";
	         
	        BufferedReader reader = null;
	         
	        FileWriter writer = null;
	         
	        try
	        {
	            reader = new BufferedReader(new FileReader(fileToBeModified));
	             
	            //Reading all the lines of input text file into oldContent
	             
	            String line = reader.readLine();
	             
	            while (line != null) 
	            {
	                oldContent = oldContent + line + System.lineSeparator();
	                 
	                line = reader.readLine();
	            }
	             
	            //Replacing oldString with newString in the oldContent
	             
	            String newContent = oldContent.replaceAll(line2, s1);
	             
	            //Rewriting the input text file with newContent
	             
	            writer = new FileWriter(fileToBeModified);
	             
	            writer.write(newContent);
	        }
	        catch (IOException e)
	        {
	            e.printStackTrace();
	        }
	        finally
	        {
	            try
	            {
	                //Closing the resources
	                 
	                reader.close();
	                 
	                writer.close();
	            } 
	            catch (IOException e) 
	            {
	                e.printStackTrace();
	            }
	        }
	    }
	     
	    public static void main(String[] args)
	    {
	        modifyFile("C:/StudentFile.txt", "85", "95");
	         
	        System.out.println("done");
	    }
    	    
public void StoreOwner_login() throws IOException {
	User obj3 = new User();
	obj3.login();
}

public void check_History_of_collaborator () throws IOException {
	File file = new File("Collaborator.txt");
BufferedReader br = new BufferedReader(new FileReader(file)); 
String s0=null;
System.out.println("...........Store History ...........");
System.out.println("                                     ");
while((s0 = br.readLine()) != null)  {
	  System.out.println(s0);
		 }

}

/*public void getviews() throws FileNotFoundException, IOException {
	int x = (int)(Math.random()*((15-9)+1))+9;
    System.out.println("Number of Store views : " + x);
    int s = (int)(Math.random()*((8-2)+1))+2;
    System.out.println("Number of user buy a store�s produce : " + s);
    int t = (int)(Math.random()*((7-6)+1))+6;
    System.out.println("Number of sold products in store : " + t);
}
		*/
}